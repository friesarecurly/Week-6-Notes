class PlaylistTrack < ApplicationRecord
  
end
