class Song < ApplicationRecord
  
end
