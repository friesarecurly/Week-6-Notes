class Playlist < ApplicationRecord
  
end
